package com.example.aplicativotrabalhowaterremember;

import static java.lang.Math.round;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

public class Settings extends AppCompatActivity {

    public TextView peso;
    public TextView txtViewAgua;
    public Button calcule;
    public Float total;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        peso = findViewById(R.id.edTxtPeso);
        calcule = findViewById(R.id.btnResult);
        txtViewAgua = findViewById(R.id.txtViewAgua);
        calcule.setOnClickListener(new View.OnClickListener()
        {
            public void onClick (View v) {
                total = (Float.valueOf(peso.getText().toString()))*35;
                txtViewAgua.setText("De acordo com o seu peso, você deve beber "+total+"ml de água");

            }
        });
    }
}